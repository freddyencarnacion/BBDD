create function hello_world() returns void
    language plpgsql
as
$$
BEGIN
  RAISE NOTICE 'Hello World';
END;
$$;

alter function hello_world() owner to postgres;

