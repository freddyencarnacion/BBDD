create function show_cust_plpgsql(id integer) returns customers
    language plpgsql
as
$$
DECLARE
	cust customers;
BEGIN
	SELECT * INTO cust FROM customers WHERE customerid = id;
	RETURN cust;
END;
$$;

alter function show_cust_plpgsql(integer) owner to postgres;

