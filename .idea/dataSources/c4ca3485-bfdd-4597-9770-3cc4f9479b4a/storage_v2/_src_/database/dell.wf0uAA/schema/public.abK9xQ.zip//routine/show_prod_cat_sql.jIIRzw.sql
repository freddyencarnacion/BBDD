create function show_prod_cat_sql(catid integer) returns SETOF products
    language sql
as
$$
SELECT * FROM products WHERE category = catid;
$$;

alter function show_prod_cat_sql(integer) owner to postgres;

