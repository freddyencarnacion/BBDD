create function del_under18_2() returns return_before_after
    language plpgsql
as
$$
DECLARE
before INTEGER;
after INTEGER;
BEGIN
SELECT COUNT(*) INTO before
FROM customers;
DELETE FROM customers WHERE age < 18;
SELECT COUNT(*) INTO after
FROM customers;
RETURN (before,after);
end;
$$;

alter function del_under18_2() owner to postgres;

