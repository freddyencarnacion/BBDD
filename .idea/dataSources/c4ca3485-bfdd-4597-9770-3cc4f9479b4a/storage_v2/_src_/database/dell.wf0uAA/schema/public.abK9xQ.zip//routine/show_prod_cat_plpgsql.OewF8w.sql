create function show_prod_cat_plpgsql(catid integer) returns SETOF products
    language plpgsql
as
$$
BEGIN
	RETURN QUERY
	        SELECT * FROM products WHERE category = catid;
END;
$$;

alter function show_prod_cat_plpgsql(integer) owner to postgres;

