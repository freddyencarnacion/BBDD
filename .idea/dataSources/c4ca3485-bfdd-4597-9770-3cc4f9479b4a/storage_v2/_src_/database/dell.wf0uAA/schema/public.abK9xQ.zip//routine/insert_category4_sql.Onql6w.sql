create function insert_category4_sql(pcategory categories) returns void
    language sql
as
$$
INSERT INTO categories VALUES (pcategory.category,
	pcategory.categoryname);
$$;

alter function insert_category4_sql(categories) owner to postgres;

