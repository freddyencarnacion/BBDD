create function insert_category2_sql(integer, character varying) returns void
    language sql
as
$$
INSERT INTO categories VALUES ($1, $2);
$$;

alter function insert_category2_sql(integer, varchar) owner to postgres;

