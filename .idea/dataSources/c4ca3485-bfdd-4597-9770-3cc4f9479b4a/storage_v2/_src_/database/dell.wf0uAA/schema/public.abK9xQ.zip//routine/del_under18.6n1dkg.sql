create function del_under18() returns SETOF integer
    language sql
as
$$
DELETE FROM customers WHERE age < 18
RETURNING customerid
$$;

alter function del_under18() owner to postgres;

