create function insert_category3_sql(category integer, categoryname character varying) returns void
    language sql
as
$$
INSERT INTO categories VALUES (insert_category3_sql.category,
	insert_category3_sql.categoryname);
$$;

alter function insert_category3_sql(integer, varchar) owner to postgres;

