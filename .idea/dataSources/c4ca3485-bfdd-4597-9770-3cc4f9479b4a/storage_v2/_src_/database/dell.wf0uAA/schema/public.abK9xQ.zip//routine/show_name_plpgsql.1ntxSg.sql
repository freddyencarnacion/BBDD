create function show_name_plpgsql(id integer, OUT first character varying, OUT last character varying) returns record
    language plpgsql
as
$$
BEGIN
	SELECT firstname, lastname INTO first, last FROM customers
	WHERE customerid = id;
END;
$$;

alter function show_name_plpgsql(integer, out varchar, out varchar) owner to postgres;

