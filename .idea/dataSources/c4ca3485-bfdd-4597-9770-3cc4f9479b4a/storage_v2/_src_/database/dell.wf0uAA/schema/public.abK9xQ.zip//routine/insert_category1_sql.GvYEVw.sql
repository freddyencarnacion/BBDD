create function insert_category1_sql(pcategory integer, pname character varying) returns void
    language sql
as
$$
INSERT INTO categories VALUES (pcategory, pname);
$$;

alter function insert_category1_sql(integer, varchar) owner to postgres;

