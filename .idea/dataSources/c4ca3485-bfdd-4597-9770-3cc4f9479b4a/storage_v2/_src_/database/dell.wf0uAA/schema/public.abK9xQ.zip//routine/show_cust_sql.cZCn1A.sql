create function show_cust_sql(id integer) returns customers
    language sql
as
$$
SELECT * FROM customers WHERE customerid = id;
$$;

alter function show_cust_sql(integer) owner to postgres;

