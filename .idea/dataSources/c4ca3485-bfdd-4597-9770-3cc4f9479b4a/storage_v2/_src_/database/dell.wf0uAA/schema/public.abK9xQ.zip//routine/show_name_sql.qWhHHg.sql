create function show_name_sql(id integer, OUT first character varying, OUT last character varying) returns record
    language sql
as
$$
SELECT firstname, lastname FROM customers WHERE customerid = id;
$$;

alter function show_name_sql(integer, out varchar, out varchar) owner to postgres;

